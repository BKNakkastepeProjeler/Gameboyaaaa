#pragma once
#include <Arduino.h>

struct NetworkCredentials
{
    String SSID;
    String PASSWORD;
};

namespace Config
{
    bool Initialize();

    extern String MasterKey;
    extern NetworkCredentials NetworkCreds;
}