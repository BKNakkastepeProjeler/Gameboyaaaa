#pragma once
#include <SD.h>


namespace DataSaving
{
    bool Initialize();
    

    bool OpenRead(const char* path, File& file);

    bool OpenWrite(const char* path, File& file);
    
    
}