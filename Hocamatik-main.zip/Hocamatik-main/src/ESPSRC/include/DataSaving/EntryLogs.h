#pragma once
#include <Arduino.h>

struct EntryLog
{
    uint8_t CardID[3];
    bool inOut; // 1: IN / 0: OUT
    ulong timestamp;
};

namespace Users
{
    bool NewEntryLog(EntryLog log);

    
}
