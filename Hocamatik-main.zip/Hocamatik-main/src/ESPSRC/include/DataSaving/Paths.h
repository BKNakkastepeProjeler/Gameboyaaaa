#pragma once

namespace Paths
{
     extern const char* FPATH_USERS;
     extern const char* FPATH_SUBJECTS;

     extern const char* FPATH_NETWORKCONFIG;

     extern const char* FPATH_MASTERKEY;
}