#pragma once
#include <Arduino.h>
#include "SD.h"

struct User
{
    char Name[20];
    uint8_t ID[3];
    uint8_t SubjectID;

    User(char _name[20], uint8_t _id[3], uint8_t _subjectid)
    {
        memset(Name, 0, 20);
        memset(ID, 0, 3);
        
        SubjectID = _subjectid;
        memcpy(Name, _name, 20);
        memcpy(ID, _id, 3);
    }
    
    User(char _name[20], uint8_t _manid, uint16_t _cardid, uint8_t _subjectid)
    {
        memset(Name, 0, 20);
        memset(ID, 0, 3);


        SubjectID = _subjectid;

        memcpy(Name, _name, 20);

        ID[0] = _manid;
        ID[1] = _cardid >> 8;
        ID[2] = _cardid & 0xFF;
    }

    User()
    {
        
    }
};

namespace Users
{
    bool AddUser(User user);

    bool GetUserByID(uint8_t ID[3], User & usr);

    bool UserExists(uint8_t ID[3]);

    File GetUsersFile(bool& suc);

    bool DeleteUserByID(uint8_t ID[3]);
}
