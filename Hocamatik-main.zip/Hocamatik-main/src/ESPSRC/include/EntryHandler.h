#pragma once
#include <Arduino.h>
#include "AsyncDelay.h"

namespace EntryHandler
{
    
    extern bool autoAdd_Active;
    extern String autoAdd_Namesurname;
    extern uint8_t autoAdd_SubjectID;
    extern AsyncDelay autoAdd_Expire;

    void HandleEntry(uint8_t cardid[3]);
}