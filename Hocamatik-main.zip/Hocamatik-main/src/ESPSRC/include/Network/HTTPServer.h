#pragma once

namespace HTTPServer
{

    bool Initialize();
}