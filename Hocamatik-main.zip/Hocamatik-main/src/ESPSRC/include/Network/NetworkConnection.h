#pragma once
namespace NetworkConnection
{
    bool Initialize();
    void EnsureConnection();
}