#pragma once

#define PIN_RFID_D0 15
#define PIN_RFID_D1 2

#define PIN_SD_CS 5