#pragma once

namespace RFIDReader
{
    bool Initialize();
    void RFIDCheck();
}
