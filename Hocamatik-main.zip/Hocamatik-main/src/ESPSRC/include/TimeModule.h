#pragma once

namespace TimeModule
{
    bool Initialize();
    
    tm ConvertEpoch(const time_t epoch);
}