#include <Pinout.h>
#include "SD.h"
#include "Debugger.h"

namespace DataSaving
{
    bool Initialize()
    {
        DebugInfo("Initializing SD");

        if (!SD.begin(PIN_SD_CS))
        {
            DebugError("SD Init failed");
            return false;
        }
        
        return true;
    }

    bool OpenRead(const char *path, File &file)
    {
        if (!SD.exists(path))
        {
            DebugWarning("File does not exist");
            return false;
        }
        
        file = SD.open(path, FILE_READ);
        return true;
    }

    bool OpenWrite(const char *path, File &file)
    {
        if (!SD.exists(path))
        {

            DebugWarning("File does not exist");
            return false;
        }

        file = SD.open(path, FILE_WRITE);
        return true;
    }

    bool CreateFile(const char *path)
    {
        File file = SD.open(path, FILE_WRITE);
        file.close();
        return true;
    }
    
}
