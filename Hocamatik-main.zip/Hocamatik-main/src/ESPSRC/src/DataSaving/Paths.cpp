namespace Paths
{
     
     const char* FPATH_USERS = "/data/users.bin"; 
     const char* FPATH_SUBJECTS = "/data/subjects.bin"; 

     const char* FPATH_NETWORKCONFIG = "/config/network.txt";

     
     const char* FPATH_MASTERKEY = "/config/masterkey.txt";
}