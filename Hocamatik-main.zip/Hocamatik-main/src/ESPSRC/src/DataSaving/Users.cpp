#include "DataSaving/DataSaving.h"
#include "DataSaving/Users.h"
#include "DataSaving/Paths.h"
#include "Debugger.h"

namespace Users // USER: 24 BYTES // 1: SUBJECT // 3: ID // 20: NAME
{
    // NAME MUST BE ASCII

    void ConvertUserToBytes(User user, uint8_t* buffer)
    {
        memcpy(buffer, &user.SubjectID, 1);
        memcpy(buffer + 1, user.ID, 3);
        memcpy(buffer + 4, user.Name, strlen(user.Name));
    }

    bool isUserDeleted(uint32_t offset, File& file)
    {
        file.seek(offset);
        uint8_t subID = 0;
        if(!file.read(&subID, 1))
        {
            DebugInfo("Failed to read subject ID");
            return false;
        }
        if(subID == 0)
        {
            DebugInfo("subject ID = 0");
            return true;
        }

        DebugInfo("Default");
        return false;
    }

    int32_t GetNewUserOffset()
    {
        File file;
        if(!DataSaving::OpenRead(Paths::FPATH_USERS, file)) return -1;

        for (uint16_t i = 0; i < file.size() / 24; i++)
        {
            uint16_t offset = i * 24;

            if(isUserDeleted(offset, file))
            {
                DebugInfo("User deleted, offset: " + String(offset));
                return offset;
            }
        }

        DebugInfo("No deleted user found, offset: filesize");
        return file.size();
    }

    bool UserExists(uint8_t ID[3])
    {
        File file;
        if(!DataSaving::OpenRead(Paths::FPATH_USERS, file)) return false;

        for (uint16_t i = 0; i < file.size() / 24; i++)
        {
            uint16_t offset = i * 24;
            if(isUserDeleted(offset, file)) continue;

            file.seek(offset);

            file.seek(offset + 1);

            uint8_t idbuffer[3];
            uint8_t idreadres = file.read(idbuffer, 3);
            if(idreadres != 3) continue;

            if(memcmp(ID, idbuffer, 3) == 0) 
            {
                file.close();
                return true;
            }
        }

        file.close();

        return false;
    }

    bool DeleteUserByID(uint8_t ID[3])
    {
        File file;
        if(!DataSaving::OpenRead(Paths::FPATH_USERS, file)) return false;

        for (uint16_t i = 0; i < file.size() / 24; i++)
        {
            uint16_t offset = i * 24;
            if(isUserDeleted(offset, file)) continue;

            file.seek(offset);
            uint8_t delres = file.write(0);

            file.close();

            return delres == 1;
        }

        file.close();

        return false;
    }

    bool GetUserByID(uint8_t ID[3], User & usr)
    {
        File file;
        if(!DataSaving::OpenRead(Paths::FPATH_USERS, file)) return false;

        for (uint16_t i = 0; i < file.size() / 24; i++)
        {
            uint16_t offset = i * 24;
            if(isUserDeleted(offset, file)) continue;

            file.seek(offset + 1);
            uint8_t idbuffer[3];

            uint8_t idreadres = file.read(idbuffer, 3);
            if(idreadres != 3) continue;

            if(memcmp(ID, idbuffer, 3) == 0)
            {
                file.seek(offset);

                uint8_t SubjectID = 0;
                uint8_t subjectidreadres = file.read(&SubjectID, 1);
                if(subjectidreadres != 1) continue;

                file.seek(offset + 4);

                char name[20];
                uint8_t namereadres = file.read((uint8_t*)name, 20);
                if(namereadres != 20) continue;

                usr = User(name, idbuffer, SubjectID);
                file.close();
                return true;
            }
        }

        file.close();

        return false;
        
    }

    bool AddUser(User user)
    {
        File file;
        if(!DataSaving::OpenWrite(Paths::FPATH_USERS, file)) return false;

        uint8_t buffer[24];
        memset(buffer, 0, sizeof(buffer));

        ConvertUserToBytes(user, buffer);

        bool seekSuc = file.seek(file.size());
        if(!seekSuc) return false;

        uint8_t written = file.write(buffer, 24);

        file.close();
        return written == 24;
    }

    File GetUsersFile(bool& suc)
    {
        File file;
        if(!DataSaving::OpenRead(Paths::FPATH_USERS, file)){suc = false; return file;}

        file.seek(0);
        suc = true;
        return file;
    }



}