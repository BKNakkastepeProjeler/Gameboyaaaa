#include <Arduino.h>
#include "DataSaving/EntryLogs.h"
#include "DataSaving/Users.h"
#include "Debugger.h"
#include "Feedback/LCD.h"
#include "AsyncDelay.h"

namespace EntryHandler
{
    bool autoAdd_Active = false;
    String autoAdd_Namesurname = "";
    uint8_t autoAdd_SubjectID = 0;
    AsyncDelay autoAdd_Expire = AsyncDelay();
    
    void HandleAutoAdd(uint8_t cardid[3])
    {
        if(Users::UserExists(cardid))
        {
            LCD::PrintCenter("Kullanici Zaten Kayitli");
            delay(1000);
            LCD::PrintCenterRow(autoAdd_Namesurname, 0);
            LCD::PrintCenterRow("Kart Bekleniyor", 1);
            return;
        }

        User user = User((char*)autoAdd_Namesurname.c_str(), cardid, autoAdd_SubjectID);
        if(!Users::AddUser(user))
        {
            LCD::PrintCenter("Kullanici Eklenemedi");
            delay(1000);
            LCD::PrintCenterRow(autoAdd_Namesurname, 0);
            LCD::PrintCenterRow("Kart Bekleniyor", 1);
            return;
        }

        LCD::PrintCenterRow(user.Name, 0);
        LCD::PrintCenterRow("Kaydedildi", 1);

        autoAdd_Active = false;

        delay(2000);
    }

    void HandleEntry(uint8_t cardid[3])
    {
        if(autoAdd_Active && !autoAdd_Expire.isExpired())
        {
            HandleAutoAdd(cardid);
            return;
        }
        
        #ifdef DEBUGINFO
        uint8_t manufacturerID = cardid[0];
        uint16_t UID = (cardid[1] << 8) | cardid[2];
        DebugInfo("ManID: " + String(manufacturerID) + " UID: " + String(UID));
        #endif

        User user = User();

        if(!Users::GetUserByID(cardid, user))
        {
            LCD::PrintCenter("Gecersiz Kart");
            delay(1000);
            return;
        }

        String name = String(user.Name);

        uint8_t SubjectID = user.SubjectID;

        LCD::PrintCenterRow(name, 0);
        LCD::PrintCenterRow("SubID: " + String(SubjectID), 1);

        delay(2000);

    }
}