#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include "Debugger.h"
#include "DataSaving/Config.h"
#include "DataSaving/Subjects.h"
#include "DataSaving/Users.h"
#include "EntryHandler.h"
#include "Feedback/LCD.h"

namespace HTTPServer
{
    AsyncWebServer server(80);


    

    void REQ_ValidateMasterKey(AsyncWebServerRequest* request);
    void REQ_Ping(AsyncWebServerRequest* request);
    void REQ_Restart(AsyncWebServerRequest* request);
    void REQ_Subject_Add(AsyncWebServerRequest* request);
    void REQ_Subject_List(AsyncWebServerRequest* request);
    void REQ_Subject_Delete(AsyncWebServerRequest* request);
    void REQ_Users_AddByID(AsyncWebServerRequest* request);
    void REQ_Users_AutoAdd(AsyncWebServerRequest* request);
    void REQ_Users_CancelAutoAdd(AsyncWebServerRequest* request);
    void REQ_Users_List(AsyncWebServerRequest* request);
    void REQ_Users_Delete(AsyncWebServerRequest* request);

    
    bool Initialize()
    {
        DebugInfo("Initializing HTTPServer");

        server.on("/ping", HTTP_GET, REQ_Ping);

        server.on("/validatemasterkey", HTTP_GET, REQ_ValidateMasterKey);

        server.on("/restart", HTTP_GET, REQ_Restart);

        server.on("/subjects/add", HTTP_GET, REQ_Subject_Add);
        server.on("/subjects/list", HTTP_GET, REQ_Subject_List);
        server.on("/subjects/delete", HTTP_GET, REQ_Subject_Delete);

        server.on("/users/addbyid", HTTP_GET, REQ_Users_AddByID);
        server.on("/users/autoadd", HTTP_GET, REQ_Users_AutoAdd);
        server.on("/users/cancelautoadd", HTTP_GET, REQ_Users_CancelAutoAdd);
        server.on("/users/list", HTTP_GET, REQ_Users_List);
        server.on("/users/delete", HTTP_GET, REQ_Users_Delete);

        server.begin();

        return true;
    }

    bool IsMasterKeyValid(AsyncWebServerRequest* request)
    {
        if(!request->hasHeader("masterkey") || request->header("masterkey") != Config::MasterKey)
        {
            request->send(200, "text/plain", "authfail");
            DebugInfo("master key not valid");
            return false;
        }

        return true;
    }
    
    void REQ_ValidateMasterKey(AsyncWebServerRequest* request)
    {
        DebugInfo("HTTP validatemasterkey");
        if(!IsMasterKeyValid(request)) return;
        request->send(200, "text/plain", "ok");
    }

    void REQ_Ping(AsyncWebServerRequest* request)
    {
        request->send(200, "text/plain", "pong " + String(millis()));
    }

    void REQ_Restart(AsyncWebServerRequest* request)
    {
        DebugInfo("HTTP restart");
        if(!IsMasterKeyValid(request)) return;
        request->send(200, "text/plain", "ok");
        delay(1000);
        ESP.restart();
    }


    void REQ_Subject_Add(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        if(!request->hasArg("subjectname"))
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        String subjectname = request->arg("subjectname");
        subjectname.toUpperCase();

        if(subjectname.length() > 9)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        if(Subjects::SubjectExists((char*)subjectname.c_str()))
        {
            request->send(200, "text/plain", "fail");
            return;
        }
        uint8_t nextID = Subjects::GetNextID();

        bool res = Subjects::AddSubject(Subject((char*)subjectname.c_str(), nextID));

        request->send(200, "text/plain", res ? String(nextID) : "fail");
    }

    void REQ_Subject_List(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        bool suc = false;
        File str = Subjects::GetSubjectsFile(suc);

        if(!suc)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        request->send(str,"text/plain", str.size());

        str.close();
    }

    void REQ_Subject_Delete(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        request->send(200, "text/plain", "fail"); // DISABLED, TODO: ENABLE IT ONCE THE FEATURE IS READY
        return;

        if(!request->hasArg("subjectid"))
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        long __subjectID = request->arg("subjectid").toInt();

        if(__subjectID < 1 || __subjectID > 255)
        {
            request->send(200, "text/plain", "fail");
            return;
        }
        

        bool suc = Subjects::DeleteSubjectByID(__subjectID);

        request->send(200, "text/plain", suc ? "ok" : "fail");
    }


    void REQ_Users_List(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        bool suc = false;
        File str = Users::GetUsersFile(suc);

        if(!suc)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        request->send(str,"text/plain", str.size());

        str.close();
    }

    void REQ_Users_AutoAdd(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        if(!request->hasArg("subjectid") || !request->hasArg("namesurname"))
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        String namesurname = request->arg("namesurname");
        namesurname.trim();
        namesurname.toUpperCase();
        long __subjectID = request->arg("subjectid").toInt();

        if(namesurname.length() > 19)
        {
            DebugInfo("NAMESURNAMELENGTH > 19");
            request->send(200, "text/plain", "fail");
            return;
        }

        if(__subjectID < 1 || __subjectID > 255)
        {
            DebugInfo("SUBJECTID OUT OF RANGE");
            request->send(200, "text/plain", "fail");
            return;
        }

        uint8_t subjectID = (uint8_t)__subjectID;

        if(!Subjects::SubjectExists(subjectID))
        {
            DebugInfo("GIVEN SUBJECT NOT FOUND");
            request->send(200, "text/plain", "subjectdoesnotexist");
            return;
        }

        request->send(200, "text/plain", "ok");
        
        EntryHandler::autoAdd_Active = true;
        EntryHandler::autoAdd_Namesurname = namesurname;
        EntryHandler::autoAdd_SubjectID = subjectID;
        EntryHandler::autoAdd_Expire.start(20000, AsyncDelay::MILLIS);

        delay(100);

        LCD::PrintCenterRow(namesurname, 0);
        LCD::PrintCenterRow("Kart Bekleniyor", 1);
    }

    void REQ_Users_CancelAutoAdd(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;
        request->send(200, "text/plain", "ok");


        if(EntryHandler::autoAdd_Active && !EntryHandler::autoAdd_Expire.isExpired())
        {
            EntryHandler::autoAdd_Active = false;
            EntryHandler::autoAdd_Expire.expire();
        }
    }

    void REQ_Users_AddByID(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;

        if(!request->hasArg("manid") || !request->hasArg("cardid") || !request->hasArg("subjectid") || !request->hasArg("namesurname"))
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        String namesurname = request->arg("namesurname");
        namesurname.trim();
        namesurname.toUpperCase();
        long __manID = request->arg("manid").toInt();
        long __cardID = request->arg("cardid").toInt();
        long __subjectID = request->arg("subjectid").toInt();

        if(namesurname.length() > 19)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        if(__manID < 0 || __manID > 255)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        if(__cardID < 0 || __cardID > 65535)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        if(__subjectID < 1 || __subjectID > 255)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        uint8_t manID = (uint8_t)__manID;
        uint16_t cardID = (uint16_t)__cardID;
        uint8_t subjectID = (uint8_t)__subjectID;
        

        uint8_t cardIDBytes[3] = {manID, (uint8_t)(cardID >> 8), (uint8_t)(cardID & 0xFF)};
        
        if(Users::UserExists(cardIDBytes))
        {
            request->send(200, "text/plain", "cardexists");
            return;
        }

        if(!Subjects::SubjectExists(subjectID))
        {
            request->send(200, "text/plain", "subjectdoesnotexist");
            return;
        }

        bool suc = Users::AddUser(User((char*)namesurname.c_str(), cardIDBytes, subjectID));

        request->send(200, "text/plain", suc ? "ok" : "fail");
    }

    void REQ_Users_Delete(AsyncWebServerRequest* request)
    {
        if(!IsMasterKeyValid(request)) return;
        
        request->send(200, "text/plain", "fail"); // DISABLED, TODO: ENABLE IT ONCE THE FEATURE IS READY
        return;

        if(!request->hasArg("manid") || !request->hasArg("cardid"))
        {
            request->send(200, "text/plain", "fail");
            return;
        }


        long __manID = request->arg("manid").toInt();
        long __cardID = request->arg("cardid").toInt();

        
        if(__manID < 0 || __manID > 255)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        if(__cardID < 0 || __cardID > 65535)
        {
            request->send(200, "text/plain", "fail");
            return;
        }

        uint8_t manID = (uint8_t)__manID;
        uint16_t cardID = (uint16_t)__cardID;
        

        uint8_t cardIDBytes[3] = {manID, (uint8_t)(cardID >> 8), (uint8_t)(cardID & 0xFF)};


        bool suc = Users::DeleteUserByID(cardIDBytes);

        request->send(200, "text/plain", suc ? "ok" : "fail");
        

    }

}