#include <Arduino.h>
#include "Debugger.h"
#include "Pinout.h"
#include "DataSaving/Users.h"
#include "EntryHandler.h"

namespace RFIDReader
{

    bool lastD0State = true;
    bool lastD1State = true;
    bool d0State = true;
    bool d1State = true;

    uint8_t index = 0;

    ulong lastOperation = 0;

    uint8_t data[3] = {0, 0, 0};
    bool LParity = 0; // Even, Leading Parity
    bool TParity = 0; // Odd, Trailing Parity

    inline void ResetValues()
    {
        index = 0;
        data[0] = 0;
        data[1] = 0;
        data[2] = 0;
        LParity = 0;
        TParity = 0;
    }

    inline void Append(bool bit)
    {
        if (index == 0)
        {
            LParity = bit;
        }
        else if (index == 25)
        {
            TParity = bit;
        }
        else
        {
            data[(index - 1) / 8] = (data[(index - 1) / 8] << 1) | bit;
        }

        index++;
        lastOperation = millis();
    }

    bool ParityCheck()
    {
        unsigned int onesCountFirstHalf = 0;
        unsigned int onesCountSecondHalf = 0;

        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (i == 1 && j == 4)
                    break;
                if ((data[i] >> j) & 1)
                {
                    onesCountFirstHalf++;
                }
            }
        }

        for (int i = 1; i < 3; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (i == 1 && j < 4)
                    continue;
                if ((data[i] >> j) & 1)
                {
                    onesCountSecondHalf++;
                }
            }
        }

        if ((onesCountFirstHalf % 2 == 0) != LParity)
            return false;
        if ((onesCountSecondHalf % 2 == 1) != TParity)
            return false;

        return true;
    }

    int c = 0;

    inline void DataCheck()
    {
        if (index == 26)
        {
            if (data[0] == 0 && data[1] == 0 && data[2] == 0)
            {
                ResetValues();
                return;
            }

            bool parityResult = ParityCheck();
            if (!parityResult)
            {
                DebugWarning("PARITY INVALID, DATA COURRUPTED");
                ResetValues();
                return;
            }

            EntryHandler::HandleEntry(data);

            ResetValues();
        }
    }

    void RFIDCheck()
    {
        if (index != 0 && millis() - lastOperation > 50)
        {
            ResetValues();
            DebugWarning("RFIDRESET");
            return;
        }

        bool d0State = digitalRead(PIN_RFID_D0);
        bool d1State = digitalRead(PIN_RFID_D1);

        if (d0State != lastD0State)
        {
            lastD0State = d0State;
            if (d0State == false)
            {
                lastD0State = d0State;
                Append(0);
            }
        }

        if (d1State != lastD1State)
        {
            lastD1State = d1State;
            if (d1State == false)
            {
                lastD0State = d0State;
                Append(1);
            }
        }

        DataCheck();
    }

    bool Initialize()
    {
        DebugInfo("Initializing RFID Reader");

        pinMode(PIN_RFID_D0, INPUT);
        pinMode(PIN_RFID_D1, INPUT);

        return true;
    }

}