#include "ESPDateTime.h"
#include "DateTimeTZ.h"
#include "Debugger.h"

namespace TimeModule
{
    bool Initialize()
    {
        DebugInfo("Initializing TimeModule");
        
        DateTime.setTimeZone(TZ_Europe_Istanbul);

        DateTime.begin(10000);
        
        return DateTime.isTimeValid();
    }

    tm ConvertEpoch(const time_t epoch)
    {
        return *localtime(&epoch);
    }

}