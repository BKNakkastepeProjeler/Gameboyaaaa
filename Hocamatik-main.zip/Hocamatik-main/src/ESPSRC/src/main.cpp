#include <Arduino.h>
#include "Debugger.h"
#include "DataSaving/DataSaving.h"
#include "RFIDReader.h"
#include "Network/NetworkConnection.h"
#include "Feedback/LCD.h"
#include "TimeModule.h"
#include "ESPDateTime.h"
#include "time.h"
#include "EntryHandler.h"
#include "AsyncDelay.h"
#include "Network/HTTPServer.h"
#include "DataSaving/Config.h"

void InitSingle(bool (*initFunc)(), const char* loadingText, const char* errorText)
{
  LCD::PrintCenter(loadingText);
  bool suc = initFunc();
  if (!suc)
  {
    LCD::PrintCenter(errorText);
    delay(3000);
    LCD::PrintCenter("Yeniden Baslatiliyor");
    delay(1500);
    ESP.restart();
  }
}

AsyncDelay timeDisplayDelay = AsyncDelay();
AsyncDelay connectionCheckDelay = AsyncDelay();

void setup()
{
  Serial.begin(9600);
  DebugInfo("BEGIN");

  LCD::Initialize();

  InitSingle(DataSaving::Initialize, "SD Kart Yukleniyor", "SD Kart Hatasi");

  InitSingle(Config::Initialize, "Konfigrasyon Aliniyor", "Konfigrasyon Hatasi");

  InitSingle(NetworkConnection::Initialize, "WiFi Baglantisi Kuruluyor", "WiFi Baglanti Hatasi");
  
  InitSingle(HTTPServer::Initialize, "Web Sunucusu Olusturuluyor", "Web Sunucu Hatasi");

  InitSingle(RFIDReader::Initialize, "RFID Okuyucu Yukleniyor", "RFID Okuyucu Hatasi");

  InitSingle(TimeModule::Initialize, "Zaman bilgisi aliniyor", "Zaman bilgisi alinamadi");

  LCD::PrintCenter("Baslatiliyor");

  timeDisplayDelay.start(1000, AsyncDelay::MILLIS);
  connectionCheckDelay.start(100, AsyncDelay::MILLIS);
}


void loop()
{
  RFIDReader::RFIDCheck();

  if(EntryHandler::autoAdd_Active)
  {
    if(EntryHandler::autoAdd_Expire.isExpired())
    {
      EntryHandler::autoAdd_Active = false;
      LCD::PrintCenter("Otomatik Ekleme Zaman Asimi");
      delay(1000);
    }

    return;
  }

  if(timeDisplayDelay.isExpired())
  {
    LCD::PrintCenter(DateTime.toString());
    timeDisplayDelay.start(1000, AsyncDelay::MILLIS);
  }

  if(connectionCheckDelay.isExpired())
  {
    NetworkConnection::EnsureConnection();
    connectionCheckDelay.start(1000, AsyncDelay::MILLIS);
  }

}