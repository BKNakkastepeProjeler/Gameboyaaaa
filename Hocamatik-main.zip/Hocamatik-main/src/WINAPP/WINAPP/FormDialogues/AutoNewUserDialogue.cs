﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WINAPP.Wrapper.Users;

namespace WINAPP.FormDialogues
{
    public partial class AutoNewUserDialogue : Form
    {
        public AutoNewUserDialogue()
        {
            InitializeComponent();


        }

        byte[] subjectIDs;

        bool saving = false;
        private void buttonSave_Click(object sender, EventArgs e)
        {
            void toggleControls(bool state)
            {
                textBoxNameSurname.Enabled = state;
                comboBoxSubject.Enabled = state;
                buttonSave.Enabled = state;
            }

            if (saving)
            {
                toggleControls(false);
                Task.Run(async delegate ()
                {
                    bool res = await Wrapper.Users.CancelAutoUserAdd();

                    if (res)
                    {
                        saving = false;
                        buttonSave.Text = "Okut Kaydet";
                        toggleControls(true);
                    }
                    else
                    {
                        MessageBox.Show(this, "İptal edilemedi, hata oluştu");
                        buttonSave.Enabled = true;
                    }
                });
            }
            else
            {
                if (comboBoxSubject.SelectedIndex == -1) { MessageBox.Show("Branş seçimi yapınız"); return; }

                string namesurname = textBoxNameSurname.Text.Trim();
                byte subjectID = subjectIDs[comboBoxSubject.SelectedIndex];

                if (namesurname.Length > 19)
                {
                    MessageBox.Show("Ad Soyad en fazla 19 karakter olabilir");
                    return;
                }

                Task.Run(async delegate ()
                {
                    toggleControls(false);

                    NewUserResult res = await Wrapper.Users.NewUserAuto(namesurname, subjectID);

                    switch (res)
                    {
                        case NewUserResult.Success:
                            saving = true;
                            buttonSave.Text = "İptal Et";
                            buttonSave.Enabled = true;
                            break;

                        case NewUserResult.SubjectDoesNotExist:
                            MessageBox.Show(this, "Branş bulunamadı");
                            toggleControls(true);
                            break;

                        case NewUserResult.Fail:
                            MessageBox.Show(this, "Hata Oluştu");
                            toggleControls(true);
                            break;

                    }

                });

            }

        }

        private void AutoNewUserDialogue_Load(object sender, EventArgs e)
        {
            Task.Run(async delegate ()
            {
                Dictionary<byte, string> subjects = await Wrapper.Subjects.ListSubjects();
                if (subjects == null)
                {
                    this.Enabled = false;
                    MessageBox.Show(this, "Branşlar yüklenemedi");
                    this.Close();
                    return;
                }

                subjectIDs = subjects.Keys.ToArray();
                foreach (string subject in subjects.Values)
                {
                    comboBoxSubject.Items.Add(subject);
                }

                labelSubjectsLoading.Visible = false;
                comboBoxSubject.Visible = true;

            });
        }

        private void AutoNewUserDialogue_FormClosing(object sender, FormClosingEventArgs e)
        {
            Task.Run(async delegate ()
            {
                await Wrapper.Users.CancelAutoUserAdd();
            });
        }
    }
}
