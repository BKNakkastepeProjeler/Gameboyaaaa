﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WINAPP.Wrapper.Users;

namespace WINAPP.FormDialogues
{
    public partial class ManualNewUserDialogue : Form
    {
        public ManualNewUserDialogue()
        {
            InitializeComponent();
        }
        byte[] subjectIDs;

        private void buttonSave_Click(object sender, EventArgs e)
        {
            void toggleControls(bool state)
            {
                textBoxNameSurname.Enabled = state;
                textBoxCardID.Enabled = state;
                textBoxManID.Enabled = state;
                comboBoxSubject.Enabled = state;
                buttonSave.Enabled = state;
            }

            if (comboBoxSubject.SelectedIndex == -1) { MessageBox.Show("Branş seçimi yapınız"); return; }

            string namesurname = textBoxNameSurname.Text.Trim();
            byte subjectID = subjectIDs[comboBoxSubject.SelectedIndex];
            
            if(!byte.TryParse(textBoxManID.Text, out byte manID))
            {
                MessageBox.Show("Geçersiz Üretici ID");
                return;
            }

            if(!UInt16.TryParse(textBoxCardID.Text, out UInt16 cardID))
            {
                MessageBox.Show("Geçersiz Kart ID");
                return;
            }

            if (namesurname.Length > 19)
            {
                MessageBox.Show("Ad Soyad en fazla 19 karakter olabilir");
                return;
            }

            Task.Run(async delegate ()
            {
                toggleControls(false);

                NewUserResult res = await Wrapper.Users.NewUserWithCardID(namesurname, subjectID, manID, cardID);

                switch (res)
                {
                    case NewUserResult.Success:
                        MessageBox.Show(this, "Kullanıcı Kaydedildi");
                        toggleControls(true);
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                        break;

                    case NewUserResult.CardExists:
                        MessageBox.Show(this, "Kart ID zaten kayıtlı");
                        toggleControls(true);
                        break;

                    case NewUserResult.SubjectDoesNotExist:
                        MessageBox.Show(this, "Branş bulunamadı");
                        toggleControls(true);
                        break;

                    case NewUserResult.Fail:
                        MessageBox.Show(this, "Hata Oluştu");
                        toggleControls(true);
                        break;

                }

            });

        }

        private void ManualNewUserDialogue_Load(object sender, EventArgs e)
        {

            Task.Run(async delegate ()
            {
                Dictionary<byte, string> subjects = await Wrapper.Subjects.ListSubjects();
                if (subjects == null)
                {
                    this.Enabled = false;
                    MessageBox.Show(this, "Branşlar yüklenemedi");
                    this.Close();
                    return;
                }

                subjectIDs = subjects.Keys.ToArray();
                foreach (string subject in subjects.Values)
                {
                    comboBoxSubject.Items.Add(subject);
                }

                labelSubjectsLoading.Visible = false;
                comboBoxSubject.Visible = true;
            });
        }
    }
}
