﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WINAPP.FormDialogues
{
    public partial class NewSubjectDialogue : Form
    {
        public NewSubjectDialogue()
        {
            InitializeComponent();
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            void toggleControls(bool state)
            {
                buttonSave.Enabled = state;
                textBoxSubjectName.Enabled = state;
            }

            Task.Run(async delegate ()
            {
                string text = textBoxSubjectName.Text.Trim();

                if (textBoxSubjectName.Text.Length > 9)
                {
                    MessageBox.Show("Branş adı 9 karakterden fazla olamaz");
                    return;
                }

                if (textBoxSubjectName.Text.Length <= 0)
                {
                    MessageBox.Show("Lütfen branş adı girin");
                    return;
                }
                toggleControls(false);
                int res = await Wrapper.Subjects.NewSubject(text);
                if (res != -1)
                {
                    MessageBox.Show("Branş eklendi");
                    toggleControls(true);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Branş eklenemedi, hata oluştu");
                    toggleControls(true);
                }
            });
            

        }
    }
}
