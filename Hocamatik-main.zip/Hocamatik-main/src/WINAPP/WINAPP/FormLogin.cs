﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WINAPP
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();

            Program.loginForm = this;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            if (!File.Exists("giris_bilgileri.txt")) return;

            string[] lines = File.ReadAllLines("giris_bilgileri.txt");
            if (lines.Length != 2) return;
            
            textBoxIPAddr.Text = lines[0];
            textBoxPW.Text = lines[1];
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            void toggleRelatedControls(bool enabled)
            {
                textBoxIPAddr.Enabled = textBoxPW.Enabled = buttonLogin.Enabled = enabled;
            }

            if (!IPAddress.TryParse(textBoxIPAddr.Text, out IPAddress IP)) { MessageBox.Show("Geçersiz IP Adresi"); return; }

            toggleRelatedControls(false);

            Task.Run(async delegate ()
            {
                (bool pingSuc, _) = await Wrapper.Misc.Ping(IP);
                if (!pingSuc) { MessageBox.Show(this, "Cihaza Bağlanılamadı"); toggleRelatedControls(true); return; }

                bool correctMasterKey = await Wrapper.Misc.Login(IP, textBoxPW.Text);
                if (!correctMasterKey) { MessageBox.Show(this, "Hatalı Şifre"); toggleRelatedControls(true); return; }

                toggleRelatedControls(true);

                this.Hide();
                new FormMain().ShowDialog();
            });
        }
    }
}
