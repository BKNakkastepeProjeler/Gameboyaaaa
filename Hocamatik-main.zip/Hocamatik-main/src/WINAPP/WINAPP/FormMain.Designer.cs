﻿namespace WINAPP
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRestart = new System.Windows.Forms.Button();
            this.buttonUserOperations = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonRestart
            // 
            this.buttonRestart.Location = new System.Drawing.Point(12, 12);
            this.buttonRestart.Name = "buttonRestart";
            this.buttonRestart.Size = new System.Drawing.Size(172, 21);
            this.buttonRestart.TabIndex = 0;
            this.buttonRestart.Text = "Cihazı Yeniden Başlat";
            this.buttonRestart.UseVisualStyleBackColor = true;
            this.buttonRestart.Click += new System.EventHandler(this.buttonRestart_Click);
            // 
            // buttonUserOperations
            // 
            this.buttonUserOperations.Location = new System.Drawing.Point(12, 56);
            this.buttonUserOperations.Name = "buttonUserOperations";
            this.buttonUserOperations.Size = new System.Drawing.Size(172, 45);
            this.buttonUserOperations.TabIndex = 1;
            this.buttonUserOperations.Tag = "UCSWITCH_UserOperations";
            this.buttonUserOperations.Text = "Kullanıcı Operasyonları";
            this.buttonUserOperations.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 158);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 45);
            this.button2.TabIndex = 2;
            this.button2.Text = "Konfigrasyon";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panelMain
            // 
            this.panelMain.Location = new System.Drawing.Point(190, 12);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(582, 437);
            this.panelMain.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 45);
            this.button1.TabIndex = 4;
            this.button1.Tag = "UCSWITCH_SubjectOperations";
            this.button1.Text = "Branş Operasyonları";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonUserOperations);
            this.Controls.Add(this.buttonRestart);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonRestart;
        private System.Windows.Forms.Button buttonUserOperations;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button button1;
    }
}