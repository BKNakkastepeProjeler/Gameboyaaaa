﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WINAPP.UserControls;

namespace WINAPP
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            UCsInit();


        }

        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        void UCsInit()
        {
            foreach (Control control in this.Controls)
            {
                if (control.GetType() != typeof(Button)) continue;
                if (control.Tag != null && control.Tag.ToString().StartsWith("UCSWITCH_"))
                {
                    string ucName = "UC_" + control.Tag.ToString().Substring(9);
                    UserControl uc = UCs.FirstOrDefault(x => x.Name == ucName);
                    if (uc == null) continue;

                    control.Click += delegate (object sender, EventArgs e)
                    {
                        panelMain.Controls.Clear();
                        panelMain.Controls.Add(uc);
                    };
                }
            }
        }

        UserControl[] UCs =
        {
            new UC_UserOperations(),
            new UC_SubjectOperations()
        };

        

        private void buttonRestart_Click(object sender, EventArgs e)
        {
            void toggleRelatedControls(bool enabled)
            {
                buttonRestart.Enabled = enabled;
            }

            Task.Run(async delegate ()
            {
                toggleRelatedControls(false);
                bool success = await Wrapper.Misc.Restart();
                if (success)
                {
                    MessageBox.Show(this, "Cihaz Yeniden Başlatıldı");
                    toggleRelatedControls(true);
                    Program.loginForm.Show();
                    this.FormClosed -= FormMain_FormClosed;
                    this.Close();
                }
                else MessageBox.Show(this, "Hata Oluştu, Cihaz Yeniden Başlatılamadı");

                toggleRelatedControls(true);

            });
        }

    }
}
