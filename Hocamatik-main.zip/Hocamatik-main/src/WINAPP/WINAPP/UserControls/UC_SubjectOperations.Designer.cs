﻿namespace WINAPP.UserControls
{
    partial class UC_SubjectOperations
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNewSubject = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.listBoxSubjects = new System.Windows.Forms.ListBox();
            this.buttonDeleteSelectedSubject = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxSubject = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonNewSubject
            // 
            this.buttonNewSubject.Location = new System.Drawing.Point(203, 3);
            this.buttonNewSubject.Name = "buttonNewSubject";
            this.buttonNewSubject.Size = new System.Drawing.Size(376, 42);
            this.buttonNewSubject.TabIndex = 9;
            this.buttonNewSubject.Text = "Yeni Branş";
            this.buttonNewSubject.UseVisualStyleBackColor = true;
            this.buttonNewSubject.Click += new System.EventHandler(this.buttonNewSubject_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(3, 403);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(194, 31);
            this.buttonRefresh.TabIndex = 8;
            this.buttonRefresh.Text = "Yenile";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(3, 3);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(194, 20);
            this.textBoxSearch.TabIndex = 7;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // listBoxSubjects
            // 
            this.listBoxSubjects.FormattingEnabled = true;
            this.listBoxSubjects.Location = new System.Drawing.Point(3, 29);
            this.listBoxSubjects.Name = "listBoxSubjects";
            this.listBoxSubjects.Size = new System.Drawing.Size(194, 368);
            this.listBoxSubjects.TabIndex = 6;
            this.listBoxSubjects.SelectedIndexChanged += new System.EventHandler(this.listBoxSubjects_SelectedIndexChanged);
            // 
            // buttonDeleteSelectedSubject
            // 
            this.buttonDeleteSelectedSubject.Location = new System.Drawing.Point(6, 75);
            this.buttonDeleteSelectedSubject.Name = "buttonDeleteSelectedSubject";
            this.buttonDeleteSelectedSubject.Size = new System.Drawing.Size(364, 42);
            this.buttonDeleteSelectedSubject.TabIndex = 4;
            this.buttonDeleteSelectedSubject.Text = "Seçili Branşı Sil";
            this.buttonDeleteSelectedSubject.UseVisualStyleBackColor = true;
            this.buttonDeleteSelectedSubject.Click += new System.EventHandler(this.buttonDeleteSelectedSubject_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxSubject);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.buttonDeleteSelectedSubject);
            this.groupBox1.Location = new System.Drawing.Point(203, 75);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(376, 125);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seçili Branş Bilgileri";
            // 
            // textBoxSubject
            // 
            this.textBoxSubject.Location = new System.Drawing.Point(120, 49);
            this.textBoxSubject.Name = "textBoxSubject";
            this.textBoxSubject.ReadOnly = true;
            this.textBoxSubject.Size = new System.Drawing.Size(136, 20);
            this.textBoxSubject.TabIndex = 8;
            this.textBoxSubject.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(120, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Branş";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // UC_SubjectOperations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonNewSubject);
            this.Controls.Add(this.buttonRefresh);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.listBoxSubjects);
            this.Controls.Add(this.groupBox1);
            this.Name = "UC_SubjectOperations";
            this.Size = new System.Drawing.Size(582, 437);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonNewSubject;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.ListBox listBoxSubjects;
        private System.Windows.Forms.Button buttonDeleteSelectedSubject;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxSubject;
        private System.Windows.Forms.Label label2;
    }
}
