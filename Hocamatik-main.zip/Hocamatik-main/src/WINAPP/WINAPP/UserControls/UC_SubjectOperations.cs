﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WINAPP.FormDialogues;
using static WINAPP.Wrapper.Users;

namespace WINAPP.UserControls
{
    public partial class UC_SubjectOperations : UserControl
    {
        public UC_SubjectOperations()
        {
            InitializeComponent();
        }
        CultureInfo enCult = new CultureInfo("en-us");


        Dictionary<byte, string> AllSubjects = new Dictionary<byte, string>();
        Dictionary<byte, string> FilteredSubjects = new Dictionary<byte, string>();


        void refreshListbox()
        {
            listBoxSubjects.Items.Clear();
            textBoxSubject.Text = null;

            string filter = textBoxSearch.Text.Trim().ToUpper(enCult);

            FilteredSubjects.Clear();
            foreach (KeyValuePair<byte,string> subject in AllSubjects)
            {
                if (string.IsNullOrEmpty(filter) || subject.Value.ToUpper(enCult).Contains(filter))
                {
                    FilteredSubjects.Add(subject.Key, subject.Value);
                    listBoxSubjects.Items.Add(subject.Value);
                }
            }
        }

        void reloadSubjects()
        {

            void toggleControls(bool state)
            {
                buttonRefresh.Enabled = state;
                listBoxSubjects.Enabled = state;
                textBoxSearch.Enabled = state;
                groupBox1.Enabled = state;
                buttonNewSubject.Enabled = state;
            }

            toggleControls(false);
            Task.Run(async delegate ()
            {
                AllSubjects.Clear();
                listBoxSubjects.Items.Clear();

                Dictionary<byte, string> _subjects = await Wrapper.Subjects.ListSubjects();

                if (_subjects == null)
                {
                    MessageBox.Show(this, "Branşlar alınamadı, hata oluştu");
                    toggleControls(true);
                    return;
                }

                AllSubjects = _subjects;

                refreshListbox();

                toggleControls(true);
            });
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            reloadSubjects();
        }

        private void buttonNewSubject_Click(object sender, EventArgs e)
        {
            if(new NewSubjectDialogue().ShowDialog() == DialogResult.OK) reloadSubjects();
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            refreshListbox();
        }

        private void buttonDeleteSelectedSubject_Click(object sender, EventArgs e)
        {
            void toggleControls(bool state)
            {
                buttonRefresh.Enabled = state;
                listBoxSubjects.Enabled = state;
                textBoxSearch.Enabled = state;
                groupBox1.Enabled = state;
                buttonNewSubject.Enabled = state;
            }

            if (listBoxSubjects.SelectedIndex == -1)
            {
                MessageBox.Show("Önce branş seçimi yapınız");
                return;
            }

            byte id = FilteredSubjects.ElementAt(listBoxSubjects.SelectedIndex).Key;



            toggleControls(false);
            Task.Run(async delegate ()
            {
                bool suc = await Wrapper.Subjects.DeleteSubject(id);

                if(suc)
                {
                    MessageBox.Show(this, "Branş başarıyla silindi");
                    reloadSubjects();
                    toggleControls(true);
                }
                else
                {
                    MessageBox.Show(this, "Branş silinemedi");
                    toggleControls(true);
                }
            });
        }

        private void listBoxSubjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBoxSubjects.SelectedIndex != -1)
            {
                textBoxSubject.Text = FilteredSubjects.ElementAt(listBoxSubjects.SelectedIndex).Value;
            }
        }
    }
}
