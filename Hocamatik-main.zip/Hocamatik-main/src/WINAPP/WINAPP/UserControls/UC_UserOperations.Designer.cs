﻿namespace WINAPP.UserControls
{
    partial class UC_UserOperations
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxUsers = new System.Windows.Forms.ListBox();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.buttonNewUserManual = new System.Windows.Forms.Button();
            this.buttonDeleteSelectedUser = new System.Windows.Forms.Button();
            this.groupBoxSelectedInfo = new System.Windows.Forms.GroupBox();
            this.textBoxCardNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxSubject = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNameSurname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonNewUserAuto = new System.Windows.Forms.Button();
            this.groupBoxSelectedInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxUsers
            // 
            this.listBoxUsers.FormattingEnabled = true;
            this.listBoxUsers.Location = new System.Drawing.Point(3, 29);
            this.listBoxUsers.Name = "listBoxUsers";
            this.listBoxUsers.Size = new System.Drawing.Size(194, 368);
            this.listBoxUsers.TabIndex = 0;
            this.listBoxUsers.SelectedIndexChanged += new System.EventHandler(this.listBoxUsers_SelectedIndexChanged);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(3, 3);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(194, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(3, 403);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(194, 31);
            this.buttonRefresh.TabIndex = 2;
            this.buttonRefresh.Text = "Yenile";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefreshUsers_Click);
            // 
            // buttonNewUserManual
            // 
            this.buttonNewUserManual.Location = new System.Drawing.Point(394, 3);
            this.buttonNewUserManual.Name = "buttonNewUserManual";
            this.buttonNewUserManual.Size = new System.Drawing.Size(185, 42);
            this.buttonNewUserManual.TabIndex = 3;
            this.buttonNewUserManual.Text = "Yeni Kullanıcı\r\n(Kart No İle)";
            this.buttonNewUserManual.UseVisualStyleBackColor = true;
            this.buttonNewUserManual.Click += new System.EventHandler(this.buttonNewUserManual_Click);
            // 
            // buttonDeleteSelectedUser
            // 
            this.buttonDeleteSelectedUser.Location = new System.Drawing.Point(6, 125);
            this.buttonDeleteSelectedUser.Name = "buttonDeleteSelectedUser";
            this.buttonDeleteSelectedUser.Size = new System.Drawing.Size(364, 42);
            this.buttonDeleteSelectedUser.TabIndex = 4;
            this.buttonDeleteSelectedUser.Text = "Seçili Kullanıcıyı Sil";
            this.buttonDeleteSelectedUser.UseVisualStyleBackColor = true;
            this.buttonDeleteSelectedUser.Click += new System.EventHandler(this.buttonDeleteSelectedUser_Click);
            // 
            // groupBoxSelectedInfo
            // 
            this.groupBoxSelectedInfo.Controls.Add(this.textBoxCardNo);
            this.groupBoxSelectedInfo.Controls.Add(this.label3);
            this.groupBoxSelectedInfo.Controls.Add(this.textBoxSubject);
            this.groupBoxSelectedInfo.Controls.Add(this.label2);
            this.groupBoxSelectedInfo.Controls.Add(this.textBoxNameSurname);
            this.groupBoxSelectedInfo.Controls.Add(this.label1);
            this.groupBoxSelectedInfo.Controls.Add(this.buttonDeleteSelectedUser);
            this.groupBoxSelectedInfo.Location = new System.Drawing.Point(203, 144);
            this.groupBoxSelectedInfo.Name = "groupBoxSelectedInfo";
            this.groupBoxSelectedInfo.Size = new System.Drawing.Size(376, 173);
            this.groupBoxSelectedInfo.TabIndex = 5;
            this.groupBoxSelectedInfo.TabStop = false;
            this.groupBoxSelectedInfo.Text = "Seçili Kullanıcı Bilgileri";
            // 
            // textBoxCardNo
            // 
            this.textBoxCardNo.Location = new System.Drawing.Point(120, 88);
            this.textBoxCardNo.Name = "textBoxCardNo";
            this.textBoxCardNo.ReadOnly = true;
            this.textBoxCardNo.Size = new System.Drawing.Size(136, 20);
            this.textBoxCardNo.TabIndex = 10;
            this.textBoxCardNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(120, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Kart No.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // textBoxSubject
            // 
            this.textBoxSubject.Location = new System.Drawing.Point(191, 44);
            this.textBoxSubject.Name = "textBoxSubject";
            this.textBoxSubject.ReadOnly = true;
            this.textBoxSubject.Size = new System.Drawing.Size(136, 20);
            this.textBoxSubject.TabIndex = 8;
            this.textBoxSubject.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(191, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Branş";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // textBoxNameSurname
            // 
            this.textBoxNameSurname.Location = new System.Drawing.Point(49, 44);
            this.textBoxNameSurname.Name = "textBoxNameSurname";
            this.textBoxNameSurname.ReadOnly = true;
            this.textBoxNameSurname.Size = new System.Drawing.Size(136, 20);
            this.textBoxNameSurname.TabIndex = 6;
            this.textBoxNameSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(49, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ad Soyad";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // buttonNewUserAuto
            // 
            this.buttonNewUserAuto.Location = new System.Drawing.Point(203, 3);
            this.buttonNewUserAuto.Name = "buttonNewUserAuto";
            this.buttonNewUserAuto.Size = new System.Drawing.Size(185, 42);
            this.buttonNewUserAuto.TabIndex = 6;
            this.buttonNewUserAuto.Text = "Yeni Kullanıcı\r\n(Okut - Kaydet)";
            this.buttonNewUserAuto.UseVisualStyleBackColor = true;
            this.buttonNewUserAuto.Click += new System.EventHandler(this.buttonNewUserAuto_Click);
            // 
            // UC_UserOperations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.buttonNewUserAuto);
            this.Controls.Add(this.groupBoxSelectedInfo);
            this.Controls.Add(this.buttonNewUserManual);
            this.Controls.Add(this.buttonRefresh);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.listBoxUsers);
            this.Name = "UC_UserOperations";
            this.Size = new System.Drawing.Size(582, 437);
            this.groupBoxSelectedInfo.ResumeLayout(false);
            this.groupBoxSelectedInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxUsers;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Button buttonNewUserManual;
        private System.Windows.Forms.Button buttonDeleteSelectedUser;
        private System.Windows.Forms.GroupBox groupBoxSelectedInfo;
        private System.Windows.Forms.TextBox textBoxNameSurname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxSubject;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCardNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonNewUserAuto;
    }
}
