﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using WINAPP.FormDialogues;
using User = WINAPP.Wrapper.Users.User;

namespace WINAPP.UserControls
{
    public partial class UC_UserOperations : UserControl
    {
        public UC_UserOperations()
        {
            InitializeComponent();
        }
        CultureInfo enCult = new CultureInfo("en-us");

        List<User> AllUsers = new List<User>();
        Dictionary<byte, string> Subjects = new Dictionary<byte, string>();

        List<User> FilteredUsers = new List<User>();

        
        void refreshListbox()
        {
            listBoxUsers.Items.Clear();
            SelectUser(null);

            string filter = textBoxSearch.Text.Trim().ToUpper(enCult);

            FilteredUsers.Clear();

            foreach (User user in AllUsers)
            {
                if (string.IsNullOrEmpty(filter) || user.NameSurname.ToUpper(enCult).Contains(filter))
                {
                    FilteredUsers.Add(user);
                    listBoxUsers.Items.Add(user.NameSurname);
                }
            }
        }

        void reloadUsers()
        {
            void toggleControls(bool state)
            {

                buttonRefresh.Enabled = state;
                listBoxUsers.Enabled = state;
                textBoxSearch.Enabled = state;
                groupBoxSelectedInfo.Enabled = state;
                buttonNewUserAuto.Enabled = state;
                buttonNewUserManual.Enabled = state;
            }

            toggleControls(false);

            Task.Run(async delegate ()
            {
                AllUsers.Clear();
                if(Subjects != null) Subjects.Clear();

                listBoxUsers.Items.Clear();

                User[] _users = await Wrapper.Users.ListUsers();
                Subjects = await Wrapper.Subjects.ListSubjects();

                if (_users == null || Subjects == null)
                {
                    MessageBox.Show("Kullanıcılar alınamadı, hata oluştu");
                    toggleControls(true);
                    return;
                }

                AllUsers = _users.ToList();

                refreshListbox();

                toggleControls(true);
            });
        }


        void SelectUser(User user)
        {
            if(user == null)
            {
                textBoxCardNo.Text = "";
                textBoxNameSurname.Text = "";
                textBoxSubject.Text = "";
                return;
            }

            textBoxNameSurname.Text = user.NameSurname;
            textBoxSubject.Text = Subjects[user.SubjectID];
            textBoxCardNo.Text = $"{user.CardManID}, {user.CardID}";
        }


        private void buttonNewUserAuto_Click(object sender, EventArgs e)
        {
            if(new AutoNewUserDialogue().ShowDialog() == DialogResult.OK) reloadUsers();
        }

        private void buttonNewUserManual_Click(object sender, EventArgs e)
        {
            if(new ManualNewUserDialogue().ShowDialog() == DialogResult.OK) reloadUsers();
        }

        private void buttonRefreshUsers_Click(object sender, EventArgs e)
        {
            reloadUsers();
            
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            refreshListbox();
        }

        private void listBoxUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxUsers.SelectedIndex != -1) SelectUser(FilteredUsers[listBoxUsers.SelectedIndex]);
        }

        private void buttonDeleteSelectedUser_Click(object sender, EventArgs e)
        {
            void toggleControls(bool state)
            {

                buttonRefresh.Enabled = state;
                listBoxUsers.Enabled = state;
                textBoxSearch.Enabled = state;
                groupBoxSelectedInfo.Enabled = state;
                buttonNewUserAuto.Enabled = state;
                buttonNewUserManual.Enabled = state;
            }

            if (listBoxUsers.SelectedIndex == -1)
            {
                MessageBox.Show("Önce kullanıcı seçimi yapınız");
                return;
            }

            User user = FilteredUsers[listBoxUsers.SelectedIndex];


            toggleControls(false);

            Task.Run(async delegate ()
            {
                bool suc = await Wrapper.Users.DeleteUser(user.CardManID, user.CardID);

                if(suc)
                {
                    MessageBox.Show(this, "Kullanıcı başarıyla silindi");
                    reloadUsers();
                    toggleControls(true);
                }
                else
                {
                    MessageBox.Show(this, "Kullanıcı silinemedi");
                    toggleControls(true);
                }
            });
        }
    }
}
