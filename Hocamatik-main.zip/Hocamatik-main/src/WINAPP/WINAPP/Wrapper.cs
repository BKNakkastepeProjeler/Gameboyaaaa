﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace WINAPP
{
    internal static class Wrapper
    {
        private class ReqResp
        {
            public bool Success = false;
            public bool authSuccess = false;
            public bool Failed { get { return stringData == "fail"; } }

            public byte[] data;
            public string stringData { get { return Encoding.UTF8.GetString(data); } }
        }

        static string MasterKEY = null;
        static string IPAddr = null;


        const string authFailResponse = "authfail";

        private static async Task<ReqResp> GETRequest(string path, TimeSpan? timeout = null)
        {
            using (HttpClient client = new HttpClient())
            using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"http://{IPAddr}{path}"))
            {
                try
                {

                    request.Headers.Add("masterkey", MasterKEY ?? "");

                    client.Timeout = timeout ?? TimeSpan.FromSeconds(5);

                    var resp = await client.SendAsync(request);
                    if (!resp.IsSuccessStatusCode) return new ReqResp();

                    var data = await resp.Content.ReadAsByteArrayAsync();
                    return new ReqResp() { Success = true, authSuccess = data != Encoding.ASCII.GetBytes(authFailResponse), data = data };
                }
                catch (Exception)
                {
                    return new ReqResp();
                }
            }
        }


        public static class Misc
        {
            public static async Task<bool> Login(IPAddress IPAddr, string masterKey)
            {
                Wrapper.IPAddr = IPAddr.ToString();
                Wrapper.MasterKEY = masterKey;

                var resp = await GETRequest("/validatemasterkey");
                return resp.Success && resp.authSuccess && resp.stringData == "ok";
            }

            public static async Task<(bool, ulong)> Ping(IPAddress IPAddr = null)
            {
                if (IPAddr != null) Wrapper.IPAddr = IPAddr.ToString();

                var resp = await GETRequest("/ping");

                if (!resp.Success) return (false, 0);
                if (resp.stringData.StartsWith("pong ")) return (true, ulong.Parse(resp.stringData.Substring(5)));

                return (false, 0);
            }

            public static async Task<bool> Restart()
            {
                var resp = await GETRequest("/restart");

                return resp.Success && resp.authSuccess && resp.stringData == "ok";
            }
        }

        public static class Subjects
        {
            public static async Task<Dictionary<byte, string>> ListSubjects()
            {
                var resp = await GETRequest("/subjects/list");

                if (!resp.Success || !resp.authSuccess || resp.Failed) return null;


                Dictionary<byte, string> subjects = new Dictionary<byte, string>();

                for (int i = 0; i < resp.data.Length / 11; i++)
                {
                    int offset = i * 11;
                    byte id = resp.data[offset];
                    string name = Encoding.UTF8.GetString(resp.data, offset + 1, 10);
                    subjects.Add(id, name);

                }

                return subjects;
            }

            public static async Task<int> NewSubject(string subject)
            {
                ReqResp resp = await GETRequest($"/subjects/add?subjectname={subject}");

                if (resp.Success && resp.authSuccess && !resp.Failed) return int.Parse(resp.stringData);
                return -1;
            }

            public static async Task<bool> DeleteSubject(byte subjectID)
            {
                ReqResp resp = await GETRequest($"/subjects/delete?subjectid={subjectID}");

                return resp.Success && resp.authSuccess && resp.stringData == "ok";
            }
        }

        public static class Users
        {
            public class User
            {
                public string NameSurname;
                public byte SubjectID;

                public byte CardManID;
                public UInt16 CardID;

                public User()
                {

                }

                public User(string nameSurname, byte subjectID, byte cardManID, ushort cardID)
                {
                    NameSurname = nameSurname;
                    SubjectID = subjectID;
                    CardManID = cardManID;
                    CardID = cardID;
                }

                public User(byte[] data)
                {
                    if (data.Length != 24) return;

                    SubjectID = data[0];

                    CardManID = data[1];

                    byte[] newcardid = new byte[2];
                    newcardid[0] = data[3];
                    newcardid[1] = data[2];

                    CardID = BitConverter.ToUInt16(newcardid, 0);

                    NameSurname = Encoding.UTF8.GetString(data, 4, 20);
                    NameSurname = NameSurname.TrimEnd('\0');
                }

            }

            public enum NewUserResult
            {
                Success,
                CardExists,
                SubjectDoesNotExist,
                Fail
            }

            public static async Task<NewUserResult> NewUserWithCardID(string nameSurname, byte subjectID, byte cardManID, UInt16 cardID)
            {
                ReqResp resp = await GETRequest($"/users/addbyid?manid={cardManID}&cardid={cardID}&subjectid={subjectID}&namesurname={nameSurname}");

                if (!resp.Success || !resp.authSuccess || resp.Failed) return NewUserResult.Fail;

                switch (resp.stringData)
                {
                    case "ok": return NewUserResult.Success;
                    case "cardexists": return NewUserResult.CardExists;
                    case "subjectdoesnotexist": return NewUserResult.SubjectDoesNotExist;
                    default: return NewUserResult.Fail;
                }

            }

            public static async Task<NewUserResult> NewUserAuto(string nameSurname, byte subjectID)
            {
                ReqResp resp = await GETRequest($"/users/autoadd?subjectid={subjectID}&namesurname={nameSurname}");

                if (!resp.Success || !resp.authSuccess || resp.Failed) return NewUserResult.Fail;
                if (resp.stringData == "ok") return NewUserResult.Success;

                if (resp.stringData == "subjectdoesnotexist") return NewUserResult.SubjectDoesNotExist;


                return NewUserResult.Fail;
            }

            public static async Task<bool> CancelAutoUserAdd()
            {
                ReqResp resp = await GETRequest($"/users/cancelautoadd");

                if (!resp.Success || !resp.authSuccess || resp.Failed) return false;

                if (resp.stringData == "ok") return true;

                return false;
            }

            public static async Task<User[]> ListUsers()
            {
                var resp = await GETRequest("/users/list");

                if (!resp.Success || !resp.authSuccess || resp.Failed) return null;

                List<User> users = new List<User>();

                for (int i = 0; i < resp.data.Length / 24; i++)
                {
                    int offset = i * 24;

                    byte[] data = new byte[24];
                    Array.Copy(resp.data, offset, data, 0, 24);
                    if (data[0] == 0) continue;

                    users.Add(new User(data));
                }

                return users.ToArray();
            }
            
            public static async Task<bool> DeleteUser(byte cardManID, UInt16 cardID)
            {
                ReqResp resp = await GETRequest($"/users/delete?manid={cardManID}&cardid={cardID}");

                return resp.Success && resp.authSuccess && resp.stringData == "ok";
            }
        }

    }
}
